export default { reactStrictMode: true, experimental: { appDir: true } };
