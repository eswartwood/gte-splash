// Fullscreen splash with invisible hotspots
import Link from "next/link";

export default function Home({ searchParams }: { searchParams?: { [key: string]: string } }) {
  const debug = !!searchParams?.debug;
  return (
    <main className={`hero ${debug ? "show-hotspots" : ""}`} aria-label="Splash">
      {/* Hidden text for screen readers */}
      <h1 className="visually-hidden">THE FUTURE OF OWNERSHIP STARTS HERE!</h1>
      <p className="visually-hidden">ART. MUSIC. REAL ESTATE. TOKENIZED.</p>

      {/* Invisible clickable areas aligned over the artwork buttons */}
      <nav className="hotspots" aria-label="Primary actions">
        <Link href="/mint/music" className="hotspot music" aria-label="Mint Music" />
        <Link href="/mint/art" className="hotspot art" aria-label="Mint Art" />
        <Link href="/mint/asset" className="hotspot asset" aria-label="Mint Asset" />
      </nav>
    </main>
  );
}
