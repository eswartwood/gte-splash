// Fullscreen splash with invisible hotspots (v2 tuned)
import Link from "next/link";

export default function Home({ searchParams }: { searchParams?: { [key: string]: string } }) {
  const debug = !!searchParams?.debug;
  return (
    <main className={`hero ${debug ? "show-hotspots" : ""}`} aria-label="Splash">
      <h1 className="visually-hidden">THE FUTURE OF OWNERSHIP STARTS HERE!</h1>
      <p className="visually-hidden">ART. MUSIC. REAL ESTATE. TOKENIZED.</p>

      <nav className="hotspots" aria-label="Primary actions">
        <Link href="/mint/music" className="hotspot music" aria-label="Mint Music" />
        <Link href="/mint/art" className="hotspot art" aria-label="Mint Art" />
        <Link href="/mint/asset" className="hotspot asset" aria-label="Mint Asset" />
      </nav>
    </main>
  );
}
