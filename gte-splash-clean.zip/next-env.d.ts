// Next.js type definitions
