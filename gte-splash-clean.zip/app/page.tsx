// Splash page component
