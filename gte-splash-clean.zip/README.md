# GTE Splash
Minimal splash page for Vercel.
